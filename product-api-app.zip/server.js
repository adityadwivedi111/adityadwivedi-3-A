const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// In-memory product store
let products = [
  { id: 1, name: 'Wireless Mouse', price: 799, rating: 4.3 },
  { id: 2, name: 'Mechanical Keyboard', price: 3499, rating: 4.6 },
  { id: 3, name: 'USB-C Hub', price: 1299, rating: 4.1 },
];
let nextId = products.length + 1;

// GET all products
app.get('/api/products', (req, res) => {
  res.json(products);
});

// GET one product
app.get('/api/products/:id', (req, res) => {
  const product = products.find((p) => p.id === Number(req.params.id));
  if (!product) return res.status(404).json({ error: 'Product not found' });
  res.json(product);
});

// POST a new product
app.post('/api/products', (req, res) => {
  const { name, price, rating } = req.body || {};
  const errors = [];

  if (typeof name !== 'string' || !name.trim()) {
    errors.push('name is required');
  }
  const priceNum = Number(price);
  if (price === undefined || price === '' || !Number.isFinite(priceNum) || priceNum < 0) {
    errors.push('price must be a non-negative number');
  }
  const ratingNum = Number(rating);
  if (rating === undefined || rating === '' || !Number.isFinite(ratingNum) || ratingNum < 0 || ratingNum > 5) {
    errors.push('rating must be a number between 0 and 5');
  }

  if (errors.length) return res.status(400).json({ errors });

  const product = {
    id: nextId++,
    name: name.trim(),
    price: priceNum,
    rating: ratingNum,
  };
  products.push(product);
  res.status(201).json(product);
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});

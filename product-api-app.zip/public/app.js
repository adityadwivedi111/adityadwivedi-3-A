const API_URL = '/api/products';

const form = document.getElementById('product-form');
const tbody = document.getElementById('products-body');
const message = document.getElementById('message');

function showMessage(text, type) {
  message.textContent = text;
  message.className = type || '';
}

function stars(rating) {
  const full = Math.round(rating);
  return '★'.repeat(full) + '☆'.repeat(5 - full);
}

// Client-side rendering: build table rows from JSON data
function renderProducts(products) {
  tbody.replaceChildren();

  if (!products.length) {
    const tr = document.createElement('tr');
    const td = document.createElement('td');
    td.colSpan = 4;
    td.className = 'empty';
    td.textContent = 'No products yet.';
    tr.appendChild(td);
    tbody.appendChild(tr);
    return;
  }

  for (const p of products) {
    const tr = document.createElement('tr');

    const idCell = document.createElement('td');
    idCell.textContent = p.id;

    const nameCell = document.createElement('td');
    nameCell.textContent = p.name; // textContent avoids HTML injection

    const priceCell = document.createElement('td');
    priceCell.textContent = '₹' + Number(p.price).toLocaleString('en-IN');

    const ratingCell = document.createElement('td');
    const starSpan = document.createElement('span');
    starSpan.className = 'stars';
    starSpan.textContent = stars(p.rating);
    ratingCell.append(starSpan, ' ' + Number(p.rating).toFixed(1));

    tr.append(idCell, nameCell, priceCell, ratingCell);
    tbody.appendChild(tr);
  }
}

async function loadProducts() {
  try {
    const res = await fetch(API_URL);
    if (!res.ok) throw new Error('Failed to load products');
    renderProducts(await res.json());
  } catch (err) {
    showMessage(err.message, 'error');
  }
}

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  showMessage('');

  const payload = {
    name: document.getElementById('name').value,
    price: document.getElementById('price').value,
    rating: document.getElementById('rating').value,
  };

  try {
    const res = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();

    if (!res.ok) {
      showMessage((data.errors || [data.error || 'Request failed']).join('; '), 'error');
      return;
    }

    form.reset();
    showMessage(`Added "${data.name}"`, 'success');
    loadProducts();
  } catch (err) {
    showMessage('Network error: ' + err.message, 'error');
  }
});

loadProducts();

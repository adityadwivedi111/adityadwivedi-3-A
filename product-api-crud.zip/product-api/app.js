const express = require('express');
const productRoutes = require('./routes/products');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

app.get('/', (req, res) => {
  res.json({
    message: 'Product API',
    endpoints: [
      'GET    /api/products',
      'GET    /api/products/:id',
      'POST   /api/products',
      'PUT    /api/products/:id',
      'PATCH  /api/products/:id',
      'DELETE /api/products/:id',
    ],
  });
});

app.use('/api/products', productRoutes);

// Unknown route
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// Error handler (covers malformed JSON bodies)
app.use((err, req, res, next) => {
  if (err.type === 'entity.parse.failed' || err.status === 400) {
    return res.status(400).json({ error: 'Request body is not valid JSON' });
  }
  console.error(err);
  res.status(500).json({ error: 'Internal server error' });
});

app.listen(PORT, () => {
  console.log(`Product API running at http://localhost:${PORT}`);
});

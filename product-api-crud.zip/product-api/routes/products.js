const express = require('express');

const router = express.Router();

// In-memory store (resets when the server restarts)
const products = [
  { id: 1, name: 'Steel Water Bottle', price: 18.5, description: 'Insulated, 750 ml, keeps drinks cold for 24 hours.' },
  { id: 2, name: 'Notebook A5', price: 4.25, description: 'Dotted pages, 120 sheets, lay-flat binding.' },
  { id: 3, name: 'Desk Lamp', price: 32, description: 'Adjustable arm with a warm LED bulb.' },
];
let nextId = 4;

// Validate a product body. With partial=true, only the fields present are checked.
function validate(body, partial = false) {
  const errors = [];
  const data = {};
  const has = (key) => body && Object.prototype.hasOwnProperty.call(body, key);

  if (!partial || has('name')) {
    if (typeof body.name !== 'string' || !body.name.trim() || body.name.trim().length > 100) {
      errors.push('name must be a text value of 1 to 100 characters');
    } else {
      data.name = body.name.trim();
    }
  }
  if (!partial || has('price')) {
    if (typeof body.price !== 'number' || !Number.isFinite(body.price) || body.price < 0) {
      errors.push('price must be a number that is 0 or more');
    } else {
      data.price = Math.round(body.price * 100) / 100;
    }
  }
  if (has('description')) {
    if (typeof body.description !== 'string' || body.description.length > 500) {
      errors.push('description must be text of at most 500 characters');
    } else {
      data.description = body.description.trim();
    }
  } else if (!partial) {
    data.description = '';
  }
  return { errors, data };
}

// Look up the product named by :id, or answer 400 / 404.
router.param('id', (req, res, next, value) => {
  if (!/^\d+$/.test(value)) {
    return res.status(400).json({ error: 'id must be a whole number' });
  }
  const product = products.find((p) => p.id === Number(value));
  if (!product) {
    return res.status(404).json({ error: `Product ${value} not found` });
  }
  req.product = product;
  next();
});

// READ all: GET /api/products  (optional ?search=text)
router.get('/', (req, res) => {
  const q = String(req.query.search || '').trim().toLowerCase();
  const list = q
    ? products.filter((p) => p.name.toLowerCase().includes(q) || p.description.toLowerCase().includes(q))
    : products;
  res.json(list);
});

// READ one: GET /api/products/:id
router.get('/:id', (req, res) => {
  res.json(req.product);
});

// CREATE: POST /api/products
router.post('/', (req, res) => {
  const { errors, data } = validate(req.body || {});
  if (errors.length) return res.status(400).json({ errors });
  const product = { id: nextId++, ...data };
  products.push(product);
  res.status(201).location(`/api/products/${product.id}`).json(product);
});

// UPDATE (replace): PUT /api/products/:id
router.put('/:id', (req, res) => {
  const { errors, data } = validate(req.body || {});
  if (errors.length) return res.status(400).json({ errors });
  Object.assign(req.product, data);
  res.json(req.product);
});

// UPDATE (partial): PATCH /api/products/:id
router.patch('/:id', (req, res) => {
  const { errors, data } = validate(req.body || {}, true);
  if (errors.length) return res.status(400).json({ errors });
  if (Object.keys(data).length === 0) {
    return res.status(400).json({ errors: ['send at least one of name, price or description'] });
  }
  Object.assign(req.product, data);
  res.json(req.product);
});

// DELETE: DELETE /api/products/:id
router.delete('/:id', (req, res) => {
  products.splice(products.indexOf(req.product), 1);
  res.status(204).end();
});

module.exports = router;

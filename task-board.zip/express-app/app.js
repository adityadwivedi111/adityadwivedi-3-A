const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Template engine: EJS, with views kept in ./views
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Parse HTML form submissions and serve ./public (stylesheet)
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

// In-memory data (resets when the server restarts)
const tasks = [
  { id: 1, title: 'Install Node.js', done: true },
  { id: 2, title: 'Build an Express app', done: false },
  { id: 3, title: 'Add a template engine', done: false },
];
let nextId = 4;
const messages = [];

const findTask = (id) => tasks.find((t) => t.id === Number(id));

// 1. GET / : home page with a summary
app.get('/', (req, res) => {
  const doneCount = tasks.filter((t) => t.done).length;
  res.render('index', {
    title: 'Home',
    total: tasks.length,
    doneCount,
    recent: tasks.slice(-3).reverse(),
  });
});

// 2. GET /about : static page
app.get('/about', (req, res) => {
  res.render('about', { title: 'About' });
});

// 3. GET /tasks : list all tasks with an add form
app.get('/tasks', (req, res) => {
  res.render('tasks', { title: 'Tasks', tasks, error: null, draft: '' });
});

// 4. POST /tasks : create a task from the form
app.post('/tasks', (req, res) => {
  const text = String(req.body.title || '').trim();
  if (!text || text.length > 100) {
    return res.status(400).render('tasks', {
      title: 'Tasks',
      tasks,
      error: 'Enter a task title of 1 to 100 characters.',
      draft: text.slice(0, 100),
    });
  }
  tasks.push({ id: nextId++, title: text, done: false });
  res.redirect('/tasks');
});

// 5. GET /tasks/:id : one task's detail page
app.get('/tasks/:id', (req, res, next) => {
  const task = findTask(req.params.id);
  if (!task) return next();
  res.render('task', { title: task.title, task });
});

// 6. POST /tasks/:id/toggle : mark done or not done
app.post('/tasks/:id/toggle', (req, res, next) => {
  const task = findTask(req.params.id);
  if (!task) return next();
  task.done = !task.done;
  res.redirect(req.get('referer') && req.get('referer').includes(`/tasks/${task.id}`) ? `/tasks/${task.id}` : '/tasks');
});

// 7. POST /tasks/:id/delete : remove a task
app.post('/tasks/:id/delete', (req, res, next) => {
  const index = tasks.findIndex((t) => t.id === Number(req.params.id));
  if (index === -1) return next();
  tasks.splice(index, 1);
  res.redirect('/tasks');
});

// 8. GET /contact : contact form
app.get('/contact', (req, res) => {
  res.render('contact', { title: 'Contact', error: null, form: {} });
});

// 9. POST /contact : receive the form and show a thank-you page
app.post('/contact', (req, res) => {
  const form = {
    name: String(req.body.name || '').trim(),
    message: String(req.body.message || '').trim(),
  };
  if (!form.name || !form.message) {
    return res.status(400).render('contact', {
      title: 'Contact',
      error: 'Both name and message are required.',
      form,
    });
  }
  messages.push({ ...form, receivedAt: new Date() });
  res.render('thanks', { title: 'Thank you', name: form.name, count: messages.length });
});

// 404 for anything unmatched
app.use((req, res) => {
  res.status(404).render('404', { title: 'Not found' });
});

// Error handler
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).send('Something went wrong.');
});

app.listen(PORT, () => {
  console.log(`Task Board running at http://localhost:${PORT}`);
});

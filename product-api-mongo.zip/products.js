const express = require('express');
const mongoose = require('mongoose');
const Product = require('../models/Product');

const router = express.Router();

// Reject malformed ids before they reach MongoDB
router.param('id', (req, res, next, id) => {
  if (!mongoose.isValidObjectId(id)) {
    return res.status(400).json({ error: 'Invalid product id' });
  }
  next();
});

// Only allow known fields (prevents mass-assignment of arbitrary data)
const pick = (body) => {
  const allowed = ['name', 'description', 'price', 'category', 'stock'];
  return Object.fromEntries(
    Object.entries(body || {}).filter(([key]) => allowed.includes(key))
  );
};

const handleError = (err, res) => {
  if (err.name === 'ValidationError') {
    return res.status(400).json({ error: err.message });
  }
  console.error(err);
  res.status(500).json({ error: 'Internal server error' });
};

// CREATE  -> POST /products
router.post('/', async (req, res) => {
  try {
    const product = await Product.create(pick(req.body));
    res.status(201).json(product);
  } catch (err) {
    handleError(err, res);
  }
});

// READ ALL -> GET /products   (optional ?category=...)
router.get('/', async (req, res) => {
  try {
    const filter = {};
    if (req.query.category) filter.category = req.query.category;
    const products = await Product.find(filter).sort({ createdAt: -1 });
    res.json(products);
  } catch (err) {
    handleError(err, res);
  }
});

// READ ONE -> GET /products/:id
router.get('/:id', async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) return res.status(404).json({ error: 'Product not found' });
    res.json(product);
  } catch (err) {
    handleError(err, res);
  }
});

// UPDATE (full/partial) -> PUT /products/:id
router.put('/:id', async (req, res) => {
  try {
    const product = await Product.findByIdAndUpdate(
      req.params.id,
      pick(req.body),
      { new: true, runValidators: true }
    );
    if (!product) return res.status(404).json({ error: 'Product not found' });
    res.json(product);
  } catch (err) {
    handleError(err, res);
  }
});

// DELETE -> DELETE /products/:id
router.delete('/:id', async (req, res) => {
  try {
    const product = await Product.findByIdAndDelete(req.params.id);
    if (!product) return res.status(404).json({ error: 'Product not found' });
    res.json({ message: 'Product deleted', id: product._id });
  } catch (err) {
    handleError(err, res);
  }
});

module.exports = router;

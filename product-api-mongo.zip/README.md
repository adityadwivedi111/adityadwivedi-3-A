# Product API (Express + MongoDB)

RESTful CRUD API for product data, using Express and Mongoose.

## Setup

```bash
npm install
cp .env.example .env     # edit MONGODB_URI if needed (local or MongoDB Atlas)
npm start                # or: npm run dev
```

Requires Node.js 18+ and a running MongoDB instance
(default: `mongodb://127.0.0.1:27017/productdb`).

## Routes

| Method | Route            | Action                         |
|--------|------------------|--------------------------------|
| POST   | `/products`      | Create a product               |
| GET    | `/products`      | List products (`?category=x`)  |
| GET    | `/products/:id`  | Get one product                |
| PUT    | `/products/:id`  | Update a product               |
| DELETE | `/products/:id`  | Delete a product               |

## Product schema

| Field         | Type   | Notes                    |
|---------------|--------|--------------------------|
| `name`        | String | required                 |
| `description` | String | optional                 |
| `price`       | Number | required, >= 0           |
| `category`    | String | default `general`        |
| `stock`       | Number | default 0, >= 0          |

`createdAt` / `updatedAt` are added automatically.

## Try it with curl

```bash
# Create
curl -X POST http://localhost:3000/products \
  -H "Content-Type: application/json" \
  -d '{"name":"Laptop","description":"14-inch","price":55000,"category":"electronics","stock":10}'

# Read all / one
curl http://localhost:3000/products
curl http://localhost:3000/products/<id>

# Update
curl -X PUT http://localhost:3000/products/<id> \
  -H "Content-Type: application/json" \
  -d '{"price":52000,"stock":8}'

# Delete
curl -X DELETE http://localhost:3000/products/<id>
```
